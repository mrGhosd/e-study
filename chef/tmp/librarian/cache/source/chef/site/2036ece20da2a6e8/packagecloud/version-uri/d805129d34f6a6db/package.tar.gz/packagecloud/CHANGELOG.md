packagecloud
===============
This is the Changelog for the packagecloud cookbook

v0.2.3 (2016-06-1)
-------------------
Try to fix metadata_expire type (set as String)

v0.2.2 (2016-06-1)
-------------------
Try to fix metadata_expire type (set as Integer)

v0.2.1 (2016-05-31)
-------------------
Set metadata_expire option to default of 300 (5 minutes) to match the
generated configs produced by the bash and manual install instructions.


v0.2.0 (2015-02-17)
-------------------
Rework GPG paths to support new GPG endpoints for repos with repo-specific GPG
keys. Old endpoints/URLs still work, too.


v0.0.1 (2014-06-05)
-------------------
Initial release.


v0.0.1 (2014-06-05)
-------------------
Initial release!
