name             'packagecloud'
maintainer       'James Golick'
maintainer_email 'james@packagecloud.io'
license          'All rights reserved'
description      'Installs/Configures packagecloud.io repositories.'
long_description 'Installs/Configures packagecloud.io repositories.'
version          '0.0.6'

depends "apt"
