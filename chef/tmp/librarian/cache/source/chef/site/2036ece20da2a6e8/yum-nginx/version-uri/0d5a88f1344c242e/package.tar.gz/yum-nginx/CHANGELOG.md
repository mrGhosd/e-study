yum-nginx CHANGELOG
=====================

This file is used to list changes made in each version of the yum-nginx
cookbook.

0.1.0
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - initial release of yum-nginx
