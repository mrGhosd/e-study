yum-epel Cookbook CHANGELOG
======================

v0.6.1 (2015-06-21)
-------------------
- Switching to https for URL links
- Using metalink URLs

v0.6.0 (2015-01-03)
-------------------
- Adding EL7 support

v0.5.3 (2014-10-28)
-------------------
- Revert Use HTTPS for GPG keys and mirror lists

v0.5.2 (2014-10-28)
-------------------
- Use HTTPS for GPG keys and mirror lists
- Use local key on Amazon Linux

v0.5.0 (2014-09-02)
-------------------
- Add all attribute available to LWRP to allow for tuning.

v0.4.0 (2014-07-27)
-------------------
- [#9] Allowing list of repositories to reference configurable.


v0.3.6 (2014-04-09)
-------------------
- [COOK-4509] add RHEL7 support to yum-epel cookbook


v0.3.4 (2014-02-19)
-------------------
COOK-4353 - Fixing typo in readme


v0.3.2 (2014-02-13)
-------------------
Updating README to explain the 'managed' parameter


v0.3.0 (2014-02-12)
-------------------
[COOK-4292] - Do not manage secondary repos by default


v0.2.0
------
Adding Amazon Linux support


v0.1.6
------
Fixing up attribute values for EL6


v0.1.4
------
Adding CHANGELOG.md


v0.1.0
------
initial release
