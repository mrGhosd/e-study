actions :add
default_action :add

attribute :name,         :kind_of => String, :name_attribute => true
attribute :master_token, :kind_of => String
attribute :type,         :kind_of => String
