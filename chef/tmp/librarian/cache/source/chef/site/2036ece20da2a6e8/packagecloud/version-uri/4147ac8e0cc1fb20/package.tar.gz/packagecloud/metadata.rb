name             'packagecloud'
maintainer       'James Golick'
maintainer_email 'james@packagecloud.io'
license          'Apache 2.0'
description      'Installs/Configures packagecloud.io repositories.'
long_description 'Installs/Configures packagecloud.io repositories.'
version          '0.0.7'

depends "apt"
